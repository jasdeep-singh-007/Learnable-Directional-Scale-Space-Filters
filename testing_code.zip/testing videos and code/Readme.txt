-- requires keras==2.7.0, opencv==4.1.2, numpy==1.19.5, tensorflow==2.2.0


-- give input path of video file in input_video variable in Proposed_model_result_generation.py
-- give output path of video file in output_video variable in Proposed_model_result_generation.py
-- give value of magnification factor in mf variable in Proposed_model_result_generation.py