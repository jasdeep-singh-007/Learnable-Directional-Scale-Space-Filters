import cv2 
import numpy as np
import keras
from keras.models import load_model
import tensorflow as tf
def FrameCapture(path_source,path_destination): 
    # Path to video file 
    vidObj = cv2.VideoCapture(path_source) 
    count=0
    success = 1
    while success: 
        success, image = vidObj.read() 
        path=path_destination+str(count)+".jpg"
        if success:
          cv2.imwrite(path, image) 
          shape=image.shape
          count += 1       
    print('done and total frames=',count,'image shape',shape,'input',path_source)
    return count,shape
def frame_to_video(size,no_of_frames,name,format,output_folder,frame_rate):
  out = cv2.VideoWriter(name,cv2.VideoWriter_fourcc(*format), frame_rate, size) 
  for i in range(no_of_frames):
      filename=output_folder+str(i)+'.jpg'
      img = cv2.imread(filename)
      img = cv2.resize(img, size)
      out.write(img)
      # print(i)                     
  return print('output video done')

def magnification(no_of_frames,file_path,m_f,output_path):
  img_input_frame_1 = np.zeros(( 1,1280, 1280, 3)).astype('float')
  img_input_frame_2 = np.zeros(( 1,1280, 1280, 3)).astype('float')

  for i in range(no_of_frames):                             
    train_img_1 = ((cv2.imread(file_path+str(i)+'.jpg')))
    shape_input=train_img_1.shape
    train_img_1 =  cv2.resize(train_img_1, (1280, 1280))
    train_img_1 =(train_img_1/127.5)-1
    train_img_2 = ((cv2.imread(file_path+'/'+str(i+1)+'.jpg')))
    train_img_2 =  cv2.resize(train_img_2, (1280, 1280))  
    train_img_2=((train_img_2/127.5)-1)
    img_input_frame_1[0,:,:,:]=train_img_1
    img_input_frame_2[0,:,:,:]=train_img_2
    m_f_2=np.array([m_f])
    hst_predict=((motion_magnification.predict([img_input_frame_1,img_input_frame_2,m_f_2])[0]+1)*127)
    hst_predict=np.squeeze(hst_predict) 
    hst_predict =  cv2.resize(hst_predict,(shape_input[1],shape_input[0]))  
    filename = output_path+str(i)+'.jpg'
    cv2.imwrite(filename, hst_predict) 
  return print('magnification done') 

import tensorflow as tf
##D1 model
motion_magnification = tf.keras.models.load_model('./check_point/motion_magnification_model')

input_frames='./input/'
output_frames='./output/'
video_format='MJPG' #XVID, MJPG, X264, WMV1,
frame_rate=30
input_video='./balloon.avi'
output_video= './balloon_magnified.avi'

mf=10 # magnification factor
no_of_frames,size=FrameCapture(input_video,input_frames)

magnification(no_of_frames-1,input_frames,mf,output_frames)
frame_to_video((size[1],size[0]),no_of_frames-1,output_video,video_format,output_frames,frame_rate)
